<?php
class Online_registration extends Frontend_Controller{

    function __construct() {
        parent::__construct();
        $this->load->model('action');
        $this->load->library('upload');
        $this->load->library('form_validation');
        $this->load->helper('custom_helper');
        $this->load->helper("confirmation");
        $this->load->library('session');
    }

    public function index() {

		$this->data['optionalSubjects'] = config_item('optional');

		if(isset($_POST['student_submit'])) {
		    
		  $this->form_validation->set_rules('roll_no', 'Roll No', 'required|roll_no|is_unique[online_admission.roll_no]');
		  $this->form_validation->set_rules('college_id', 'College Roll', 'required|college_id|is_unique[online_admission.college_id]');
		    if($this->form_validation->run()==FALSE){
        		$msg_array=array(
        		    "title"=>"Error",
        		    "emit"=>validation_errors(),
        		    "btn"=>true
        		);
        		
/*        		$messArr = array(
                    "title" => "Warning",
                    "emit"  => "Wrong Student ID or Mobile!",
                    "btn"   => false
                );*/

                $this->session->set_flashdata('error', message('warning', $msg_array));
        		redirect('access/subscriber/online_admission_access', 'refresh');
          }else{
		  
		    
			$session = date('Y') . '-' . (date('Y') + 1);
			
			/*
			
			$path = 'public/students/';
			$upload = $this->uploadFile('students_photo', './' .$path, generator('online_admission', 'student-'));
			$photo = $path . $upload['file_name'];
			
			*/


			// working with subject
			$compulsory = array();
			$optional = array(
				"subject" 	=> $this->input->post("optional_subject"),
				"code" 		=> $this->input->post("optional_code"),
			);

			foreach ($_POST['compulsory_subject'] as $key => $input) {
				$compulsory[] = array(
					"subject"   => $input,
					"code"		=> $_POST['compulsory_code'][$key]
				);
			}

			$admissionData = array(
				"date" 				                =>  date("Y-m-d"),
                "name_english"                      =>  $this->input->post('name_english'),
                "name_bangla"                       =>  $this->input->post('name_bangla'),
                "nickname"                          =>  $this->input->post('nickname'),
                "reg_no"                            =>  $this->input->post('reg_no'),
                "college_id"                        =>  $this->input->post('college_id'),
                "roll_no"                           =>  $this->input->post('roll_no'),
                "exam_year"                         =>  $this->input->post('exam_year'),
                "ssc_session"                       =>  $this->input->post('ssc_session'),
                "ssc_group"                         =>  $this->input->post('ssc_group'),
                "ssc_record"                        =>  json_encode($this->input->post('ssc_record')),
                "compulsory_subject_grade"          =>  json_encode($this->input->post('compulsory_subject_grade')),
                "elective_subject_grade"            =>  json_encode($this->input->post('elective_subject_grade')),
                "additional_subject_grade"          =>  json_encode($this->input->post('additional_subject_grade')),
                "birth_date"                        =>  $this->input->post('birth_date'),
                "nationalitity"                     =>  $this->input->post('nationalitity'),
                "religion"                          =>  $this->input->post('religion'),
                "blood_group"                       =>  $this->input->post('blood_group'),
                "district"                          =>  $this->input->post('district'),
                "student_phone"                     =>  $this->input->post('student_phone'),
                "present_address"                   =>  $this->input->post('present_address'),
                "permanent_address"                 =>  $this->input->post('permanent_address'),
                "phone_res"                         =>  $this->input->post('phone_res'),
                "stay_with"                         =>  $this->input->post('stay_with'),
                "father_info"                       =>  json_encode($this->input->post('father_info')),
                "mother_info"                       =>  json_encode($this->input->post('mother_info')),
                "local_gurdian"                     =>  json_encode($this->input->post('local_gurdian')),
                "progress_report"                   =>  json_encode($this->input->post('progress_report')),
                "extra_activity"                    =>  json_encode($this->input->post('extra_activity')),
                "group"                             =>  $this->input->post('group'),
				//"photo" 				=> $photo,
				"photo" 				=> $this->input->post('students_photo'),
				"compulsory" 	        => json_encode($compulsory),
				"optional" 		        => json_encode($optional)				
			);

			//$status = $this->action->add('online_admission', $admissionData);
			$status = $this->action->addAndGetID('online_admission', $admissionData);

			$options = array(
				"title" => "Success",
				"emit"  => "Student admission successfully completed!",
				"btn"   => true
			);
			
			$info = $this->action->read('online_admission',array(),'desc');
			$this->session->set_flashdata('conmirmation', message('success', $options));
			redirect('access/subscriber/form/'.$status, 'refresh');
		    }
	    }
    }

	private function uploadFile($filedname, $path, $filename){
		$uploadData = array();
		$config = array();

		if($_FILES[$filedname]['name'] != null) {
			$config['upload_path'] 		= $path;
			$config['allowed_types'] 	= 'png|jpeg|jpg|gif|bmp';
			$config['max_size'] 		= '4096';
			$config['max_width'] 		= '3000';
			$config['max_height'] 		= '3000';
			$config['file_name'] 		= $filename;
			$config['overwrite']		= true;

			$this->upload->initialize($config);

            if($this->upload->do_upload($filedname)) {
            	$uploadData = $this->upload->data();

				return $uploadData;
		  	}
		}

		return FALSE;
	}
	
}
