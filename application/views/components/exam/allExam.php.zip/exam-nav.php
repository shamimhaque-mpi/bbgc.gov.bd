<div class="container-fluid none" <?php echo $subMenu; ?> style="margin-bottom: 10px;">
    <div class="row">	
              <a href="<?php echo site_url('exam/exam/setNewExam'); ?>" class="btn btn-default" id="add-new-name">
			Exam Name
		</a>
		<a href="<?php echo site_url('exam/exam'); ?>" class="btn btn-default" id="add-new">
			Add Exam
		</a>


		<a href="<?php echo site_url('exam/exam/allExam'); ?>" class="btn btn-default" id="all">
			All Exam
		</a>
		
    </div>
</div>